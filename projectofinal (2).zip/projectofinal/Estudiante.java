/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectofinal;

/**
 *
 * @author sharo
 */
public class Estudiante {
    //Julio
    
    //Atributos
    private String numeroCuenta;
    private String nombre;
    private String apellido;
    private int edad;
    private String correo;
    private Carrera carrera;
    private Calificaciones calificaciones;


    
    // Constructor
    public Estudiante(String numeroCuenta, String nombre, String apellido, int edad, String correo, Carrera carrera, Calificaciones calificaciones) {
        this.numeroCuenta = numeroCuenta;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.correo = correo;
        this.carrera = carrera;
        this.calificaciones = calificaciones;
    } 
    
    //Setters
    public void setNumeroCuenta(String numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setCarrera(Carrera carrera) {
        this.carrera = carrera;
    }

    public void setCalificaciones(Calificaciones calificaciones) {
        this.calificaciones = calificaciones;
    }
    
    
    
    //Getters
     public String getNumeroCuenta() {
        return numeroCuenta;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    public String getCorreo() {
        return correo;
    }

    public Carrera getCarrera() {
        return carrera;
    }

    public Calificaciones getCalificaciones() {
        return calificaciones;
    }
    
    
    // Método para imprimir la información del estudiante
    public void imprimirInformacion() {
        System.out.println("Numero de Cuenta: " + numeroCuenta);
        System.out.println("Nombre: " + nombre + " " + apellido);
        System.out.println("Edad: " + edad);
        System.out.println("Correo: " + correo);
        System.out.println("Carrera: ");
        carrera.imprimirCarrera();
        System.out.println("Calificaciones: ");
        calificaciones.imprimirCalificaciones();
        
        
       
    }

    // Filtrar estudiante por número de cuenta
    public boolean esMismoNumeroCuenta(String cuenta) {
        return this.numeroCuenta.equals(cuenta);
    }


    // Ordenar lista de estudiantes por número de cuenta
    public static void ordenarPorNumeroCuenta(Estudiante[] estudiantes) {
        for (int i = 0; i < estudiantes.length - 1; i++) {
            for (int j = i + 1; j < estudiantes.length; j++) {
                if (estudiantes[i].getNumeroCuenta().compareTo(estudiantes[j].getNumeroCuenta()) > 0) {
                    Estudiante temp = estudiantes[i];
                    estudiantes[i] = estudiantes[j];
                    estudiantes[j] = temp;
                }
            }
        }
    }


    // Ordenar lista de estudiantes por edad
    public static void ordenarPorEdad(Estudiante[] estudiantes) {
        for (int i = 0; i < estudiantes.length - 1; i++) {
            for (int j = i + 1; j < estudiantes.length; j++) {
                if (estudiantes[i].getEdad() > estudiantes[j].getEdad()) {
                    Estudiante temp = estudiantes[i];
                    estudiantes[i] = estudiantes[j];
                    estudiantes[j] = temp;
                }
            }
        }
    }

    // Eliminar alumno (vaciar los datos del estudiante)
    public void eliminarAlumno() {
        this.numeroCuenta = "";
        this.nombre = "";
        this.apellido = "";
        this.edad = 0;
        this.correo = "";
        this.carrera = null;
        this.calificaciones = null;
    }

    // Modificar los datos del alumno
    public void modificarAlumno(String nombre, String apellido, int edad, String correo, Carrera carrera, Calificaciones calificaciones) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.correo = correo;
        this.carrera = carrera;
        this.calificaciones = calificaciones;
    }

    

    
    //Josue
    public static void ordenarPorCarrera(Estudiante[] estudiantes) {
    for (int i = 0; i < estudiantes.length - 1; i++) {
        for (int j = i + 1; j < estudiantes.length; j++) {
            if (estudiantes[i].getCarrera().getNombreCarrera().compareTo(estudiantes[j].getCarrera().getNombreCarrera()) > 0) {
                Estudiante temp = estudiantes[i];
                estudiantes[i] = estudiantes[j];
                estudiantes[j] = temp;
        }   }    
     }
}
    public static void ordenarPorPromedio(Estudiante[] estudiantes) {
    for (int i = 0; i < estudiantes.length - 1; i++) {
        for (int j = i + 1; j < estudiantes.length; j++) {
            if (estudiantes[i].getCalificaciones().getPromedio() < estudiantes[j].getCalificaciones().getPromedio()) {
                Estudiante temp = estudiantes[i];
                estudiantes[i] = estudiantes[j];
                estudiantes[j] = temp;
            }
        }
    }
}

   
    public static void imprimirAprobados(Estudiante[] estudiantes) {
    System.out.println("Listado de alumnos aprobados:");
    for (Estudiante estudiante : estudiantes) {
        if (estudiante.getCalificaciones().getPromedio() >= 60) {
            System.out.println(estudiante.getNombre() + " " + estudiante.getApellido() + " - Promedio: " + estudiante.getCalificaciones().getPromedio());

        }
    }
}
    public static void imprimirReprobados(Estudiante[] estudiantes) {
    System.out.println("Listado de alumnos reprobados:");
    for (Estudiante estudiante : estudiantes) {
        if (estudiante.getCalificaciones().getPromedio() < 60) {
            System.out.println(estudiante.getNombre() + " " + estudiante.getApellido() + " - Promedio: " + estudiante.getCalificaciones().getPromedio());

        }
    }
}
    public static void imprimirListadoAprobados(Estudiante[] estudiantes) {
    System.out.println("Listado completo de alumnos aprobados:");
    imprimirAprobados(estudiantes);
}
    public static void imprimirListadoReprobados(Estudiante[] estudiantes) {
    System.out.println("Listado completo de alumnos reprobados:");
    imprimirReprobados(estudiantes);
}  }
    

