/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package projectofinal;
import java.util.Scanner;

/**
 *
 * @author sharo
 */
public class ProjectoFinal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        //Josue
        try (Scanner scanner = new Scanner(System.in)) {
            
            System.out.print("¿Cuantos estudiantes desea agregar? ");
            int numEstudiantes = scanner.nextInt();
            scanner.nextLine();
            
            
            Estudiante[] estudiantes = new Estudiante[numEstudiantes];

            
            
            for (int i = 0; i < numEstudiantes; i++) {
                System.out.println("Ingrese los datos del estudiante " + (i + 1) + ":");
                
                System.out.println("Numero de cuenta: ");
                String numeroCuenta = scanner.nextLine();
                
                System.out.print("Nombre: ");
                String nombre = scanner.nextLine();
                
                System.out.print("Apellido: ");
                String apellido = scanner.nextLine();
                
                System.out.print("Edad: ");
                int edad = scanner.nextInt();
                
                System.out.print("Correo: ");
                scanner.nextLine();
                String correo = scanner.nextLine();
                
                
                
                System.out.print("Carrera (Código y Nombre): "); //Sharon
                String CodigoCarrera = scanner.nextLine();
                String NombreCarrera = scanner.nextLine();
                Carrera carrera = new Carrera(CodigoCarrera, NombreCarrera);
                
                System.out.print("Examen 1: ");
                double Examen1 = scanner.nextDouble();
                System.out.print("Examen 2: ");
                double Examen2 = scanner.nextDouble();
                System.out.print("Acumulativo: ");
                double Acumulativo = scanner.nextDouble();
                scanner.nextLine();
                
                Calificaciones calificaciones = new Calificaciones(Examen1, Examen2, Acumulativo, 0);
                
                estudiantes[i] = new Estudiante(numeroCuenta, nombre, apellido, edad, correo, carrera, calificaciones);


            }
            
            
            boolean salir = false;
            while (!salir) {
                System.out.println("\n¿Que desea hacer?");
                System.out.println("1. Modificar estudiante");
                System.out.println("2. Eliminar estudiante");
                System.out.println("3. Filtrar estudiante por cuenta");
                System.out.println("4. Ordenar estudiantes por edad");
                System.out.println("5. Ordenar estudiantes por cuenta");
                System.out.println("6. Ingresar calificaciones");
                System.out.println("7. Imprimir estudiantes con su promedio final");
                System.out.println("8. Imprimir listado de alumnos aprobados");
                System.out.println("9. Imprimir listado de alumnos reprobados");
                System.out.println("0. Salir");
                
                int opcion = scanner.nextInt();
                scanner.nextLine();
                
                switch (opcion) {
                    case 1:
                        
                        System.out.print("Ingrese el numero de cuenta del estudiante a modificar: ");
                        String cuentaModificar = scanner.nextLine();
                        boolean encontradoModificar = false;
                        for (Estudiante e : estudiantes) {
                            if (e.esMismoNumeroCuenta(cuentaModificar)) {
                                encontradoModificar = true;
                                System.out.println("Ingrese los nuevos datos del estudiante:");
                                
                                System.out.print("Nombre: ");
                                String nuevoNombre = scanner.nextLine();
                                
                                System.out.print("Apellido: ");
                                String nuevoApellido = scanner.nextLine();
                                
                                System.out.print("Edad: ");
                                int nuevaEdad = scanner.nextInt();
                                
                                System.out.print("Correo: ");
                                scanner.nextLine();
                                String nuevoCorreo = scanner.nextLine();
                                
                                System.out.print("Carrera (Código y Nombre): ");
                                String nuevoCodigoCarrera = scanner.nextLine();
                                String nuevoNombreCarrera = scanner.nextLine();
                                Carrera nuevaCarrera = new Carrera(nuevoCodigoCarrera, nuevoNombreCarrera);
                                
                                
                                System.out.print("Examen 1: ");
                                double examen1 = scanner.nextDouble();

                                System.out.print("Examen 2: ");
                                double examen2 = scanner.nextDouble();

                                System.out.print("Acumulativo: ");
                                double acumulativo = scanner.nextDouble();
                                scanner.nextLine(); 

                                Calificaciones nuevasCalificaciones = new Calificaciones(examen1, examen2, acumulativo, 0);
                                
                                e.modificarAlumno(nuevoNombre, nuevoApellido, nuevaEdad, nuevoCorreo, nuevaCarrera, nuevasCalificaciones);
                                System.out.println("Estudiante modificado.");
                                break;
                            }
                        }
                        if (!encontradoModificar) {
                            System.out.println("Estudiante no encontrado.");
                        }
                        break;
                        
                    case 2:
                        
                        System.out.print("Ingrese el numero de cuenta del estudiante a eliminar: ");
                        String cuentaEliminar = scanner.nextLine();
                        
                        for (int i = 0; i < estudiantes.length; i++) {
                            if (estudiantes[i].esMismoNumeroCuenta(cuentaEliminar)) {
                                estudiantes[i].eliminarAlumno();
                                for (int j = i; j < estudiantes.length - 1; j++) {
                                    estudiantes[j] = estudiantes[j + 1];
                                }
                                estudiantes[estudiantes.length - 1] = null;
                                System.out.println("Estudiante eliminado.");
                                break;
                            }
                        }
                        break;
                        
                    case 3:
                        
                        System.out.print("Ingrese el numero de cuenta del estudiante a filtrar: ");
                        String cuentaFiltrar = scanner.nextLine();
                        for (Estudiante e : estudiantes) {
                            if (e.esMismoNumeroCuenta(cuentaFiltrar)) {
                                e.imprimirInformacion();
                                break;
                            }
                        }
                        break;
                        
                    case 4:
                        
                        Estudiante.ordenarPorEdad(estudiantes);
                        System.out.println("Estudiantes ordenados por edad.");
                        break;
                        
                    case 5:
                        
                        Estudiante.ordenarPorNumeroCuenta(estudiantes);
                        System.out.println("Estudiantes ordenados por numero de cuenta.");
                        break;
                        
                    case 6:
                        
                        System.out.print("Ingrese el numero de cuenta del estudiante para ingresar calificaciones: ");
                        String cuentaCalificaciones = scanner.nextLine();
                        for (Estudiante e : estudiantes) {
                            if (e.esMismoNumeroCuenta(cuentaCalificaciones)) {
                                
                                System.out.print("Examen 1: ");
                                double nuevoExamen1 = scanner.nextDouble();

                                System.out.print("Examen 2: ");
                                double nuevoExamen2 = scanner.nextDouble();

                                System.out.print("Acumulativo: ");
                                double nuevoAcumulativo = scanner.nextDouble();
                                scanner.nextLine(); 

                                Calificaciones nuevasCalificacionesIngreso = new Calificaciones(nuevoExamen1, nuevoExamen2, nuevoAcumulativo, 0); // Crear nuevo objeto
                                e.modificarAlumno(e.getNombre(), e.getApellido(), e.getEdad(), e.getCorreo(), e.getCarrera(), nuevasCalificacionesIngreso);
                                System.out.println("Calificaciones actualizadas.");
                                break;
                            }
                        }
                        break;
                        
                    case 7:
                        
                        System.out.println("Listado completo de estudiantes:");
                        for (Estudiante e : estudiantes) {
                            e.imprimirInformacion();
                        }
                        break;
                        
                    case 8:
                        
                        Estudiante.imprimirListadoAprobados(estudiantes);
                        break;
                        
                    case 9:
                        
                        Estudiante.imprimirListadoReprobados(estudiantes);
                        break;
                        
                    case 0:
                        
                        salir = true;
                        System.out.println("Saliendo del programa.");
                        break;
                        
                    default:
                        System.out.println("Opcion no valida.");
                        break;
                }
            }
        }
    }
}