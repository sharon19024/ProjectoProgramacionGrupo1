/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectofinal;

/**
 *
 * @author sharo
 */
public class Calificaciones {

    

    //Sharon
    
   
    
    //Atributos
    public double Examen1;
    public double Examen2;
    public double Acumulativo;
    public double Promedio;

    
    // Constructor
    public Calificaciones(double Examen1, double Examen2, double Acumulativo, double Promedio) {
        this.Examen1 = Examen1;
        this.Examen2 = Examen2;
        this.Acumulativo = Acumulativo;
        this.Promedio = calcularPromedio();
    } 
    
    
    //SETTER
    public void setPromedio(double Promedio) {
        this.Promedio = Promedio;
    }   


    public void setExamen1(double Examen1) {
        this.Examen1 = Examen1;
    }

    public void setExamen2(double Examen2) {
        this.Examen2 = Examen2;
    }

    public void setAcumulativo(double Acumulativo) {
        this.Acumulativo = Acumulativo;
    }
    
    //GETTER 
    
    public double getExamen1() {
        return Examen1;
    }

    public double getExamen2() {
        return Examen2;
    }

    public double getAcumulativo() {
        return Acumulativo;
    }

    public double getPromedio() {
        return Promedio;
    }
    
    // Calcular el promedio
    public double calcularPromedio() {
        this.Promedio = (Examen1 + Examen2 + Acumulativo) / 3;
        return Promedio;
    }

    // Método para imprimir la información de las calificaciones
    public void imprimirCalificaciones() {
        System.out.println("Examen 1: " + Examen1);
        System.out.println("Examen 2: " + Examen2);
        System.out.println("Acumulativo: " + Acumulativo);
        System.out.println("Promedio: " + Promedio);
    }
}