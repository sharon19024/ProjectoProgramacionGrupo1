/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package projectofinal;

/**
 *
 * @author sharo
 */
public class Carrera {

    //Sharon
    //Atributos
    
    
    private String CodigoCarrera ;
    private String NombreCarrera;
    
    //Constructor 
    public Carrera(String CodigoCarrera, String NombreCarrera) {
        this.CodigoCarrera = CodigoCarrera;
        this.NombreCarrera = NombreCarrera;
        
    } 
    
    //setter
    
    public void setCodigoCarrera(String CodigoCarrera) {
        this.CodigoCarrera = CodigoCarrera;
    }

    
    public void setNombreCarrera(String NombreCarrera) {
        this.NombreCarrera = NombreCarrera;
    }
    
    
    //getter
    
     public String getCodigoCarrera() {
        return CodigoCarrera;
    }

    
    public String getNombreCarrera() {
        return NombreCarrera;
    }
    
    
    // Método para imprimir la información de la carrera
    public void imprimirCarrera() {
        System.out.println("Código de Carrera: " + CodigoCarrera);
        System.out.println("Nombre de Carrera: " + NombreCarrera);
    }
} 

